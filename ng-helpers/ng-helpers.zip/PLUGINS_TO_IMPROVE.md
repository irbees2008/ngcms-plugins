# Список плагинов для модификации с использованием ng-helpers v0.2.0

## ✅ Модернизированные плагины (Готово!)

| №   | Плагин           | Новые функции                                                                              | Новые переменные шаблонов             | Система |
| --- | ---------------- | ------------------------------------------------------------------------------------------ | ------------------------------------- | ------- |
| 1   | **breadcrumbs**  | `cache_get`, `cache_put`                                                                   | -                                     | Twig    |
| 2   | **feedback**     | `validate_email`, `csrf_field`, `validate_csrf`, `sanitize`, `logger`, `get_ip`, `is_post` | -                                     | Twig    |
| 3   | **lastcomments** | `cache_get`, `cache_put`, `time_ago`, `excerpt`, `clamp`                                   | `{time_ago}` → `{{ entry.time_ago }}` | Twig    |
| 4   | **similar**      | `array_pluck`, `cache_get`, `cache_put`, `cache_forget`, `logger`                          | -                                     | $tpl    |
| 5   | **rating**       | `is_ajax`, `get_ip`, `percentage`, `clamp`, `logger`, `cache_forget`                       | `{rating_percent}`                    | $tpl    |
| 6   | **mailing**      | `benchmark`, `logger`                                                                      | -                                     | -       |
| 7   | **gallery**      | `cache_get`, `cache_put`, `formatBytes`, `logger`, `get_ip`                                | -                                     | Twig    |
| 8   | **comments**     | `is_post`, `validate_email`, `sanitize`, `logger`, `get_ip`, `time_ago`, `excerpt`         | `{time_ago}`, `{comment_preview}`     | Mixed   |
| 9   | **auth_social**  | `random_string`, `validate_email`, `logger`, `get_ip`                                      | -                                     | -       |
| 10  | **webpush**      | `logger`, `get_ip`, `validate_url` (standalone), `is_mobile` (standalone)                  | -                                     | -       |
| 11  | **archive**      | `cache_get`, `cache_put`, `logger`                                                         | -                                     | Twig    |

**Документация:** Все плагины имеют файл `CHANGELOG_NGHELPERS.md` с подробным описанием изменений.

---

# Список плагинов для модификации с использованием ng-helpers v0.2.0

## 🎯 Приоритетные плагины (высокая польза)

### 1. **breadcrumbs** - Хлебные крошки

**Что улучшить:**

- ✅ Заменить ручную генерацию HTML на `breadcrumb()`
- ✅ Использовать `array_pluck()` для извлечения данных категорий
- ✅ Применить `cache_get()` / `cache_put()` вместо `cacheRetrieveFile()`

**Примеры применения:**

```php
use function Plugins\breadcrumb;

// Было:
$location[] = array('url' => $url, 'title' => $title, 'link' => $link);

// Стало:
$items = [
    ['title' => 'Главная', 'url' => '/'],
    ['title' => $category['name'], 'url' => $categoryUrl],
    ['title' => $currentPage]
];
$output = breadcrumb($items, ' → ');
```

---

### 2. **feedback** - Форма обратной связи

**Что улучшить:**

- ✅ `validate_email()` для проверки email полей
- ✅ `validate_phone()` для проверки телефона
- ✅ `sanitize()` для очистки пользовательских данных
- ✅ `csrf_field()` / `validate_csrf()` для защиты форм
- ✅ `is_post()` для проверки типа запроса
- ✅ `logger()` для логирования отправленных форм
- ✅ `get_ip()` для сохранения IP отправителя

**Примеры:**

```php
use function Plugins\{validate_email, sanitize, csrf_field, validate_csrf, logger, get_ip};

// Валидация
if (!validate_email($_POST['email'])) {
    $errors[] = 'Неверный email';
}

// Очистка
$message = sanitize($_POST['message']);

// CSRF защита
if (!validate_csrf()) {
    abort(403);
}

// Логирование
logger("Feedback from {$email} IP: " . get_ip(), 'info', 'feedback.log');
```

---

### 3. **lastcomments** - Последние комментарии

**Что улучшить:**

- ✅ `cache_get()` / `cache_put()` вместо `cacheRetrieveFile()`
- ✅ `time_ago()` для отображения времени комментариев
- ✅ `excerpt()` для создания превью комментариев
- ✅ `str_limit()` для обрезки текста
- ✅ `paginate()` для постраничной навигации

**Примеры:**

```php
use function Plugins\{cache_get, cache_put, time_ago, excerpt};

// Кэширование
$cacheKey = "lastcomments_{$config['theme']}_{$lang}";
if ($data = cache_get($cacheKey)) {
    return $data;
}

// Генерация данных
$result = generateComments();
cache_put($cacheKey, $result, 30);

// Форматирование
foreach ($comments as &$comment) {
    $comment['time_ago'] = time_ago($comment['postdate']);
    $comment['preview'] = excerpt($comment['text'], 150);
}
```

---

### 4. **similar** - Похожие новости

**Что улучшить:**

- ✅ `array_pluck()` для извлечения тегов
- ✅ `cache_remember()` уже используется, можно дополнить `cache_get/put`
- ✅ `collect()` для работы с коллекциями новостей
- ✅ `array_first()` / `array_last()` для выборки

**Примеры:**

```php
use function Plugins\{array_pluck, collect};

// Извлечение ID похожих новостей
$similarIds = array_pluck($similarRows, 'refNewsID');

// Работа с коллекцией
$similar = collect($similarRows)
    ->filter(function($item) {
        return $item['dimension'] == 1;
    })
    ->pluck('refNewsTitle')
    ->toArray();
```

---

### 5. **rating** - Рейтинги

**Что улучшить:**

- ✅ `is_ajax()` для обработки AJAX голосования
- ✅ `get_ip()` для учета IP голосующих
- ✅ `percentage()` для вычисления процентов рейтинга
- ✅ `json_decode_safe()` для безопасной работы с JSON
- ✅ `clamp()` для ограничения значений рейтинга

**Примеры:**

```php
use function Plugins\{is_ajax, get_ip, percentage, clamp};

if (is_ajax()) {
    $rating = clamp($_POST['rating'], 1, 5);
    $ip = get_ip();

    // Сохранение
    saveVote($newsId, $rating, $ip);

    // Ответ
    $percent = percentage($positiveVotes, $totalVotes);
    echo json_encode(['success' => true, 'percent' => $percent]);
}
```

---

### 6. **mailing** - Рассылка

**Что улучшить:**

- ✅ `validate_email()` для проверки подписчиков
- ✅ `array_pluck()` для извлечения email из БД
- ✅ `benchmark()` для замера производительности рассылки
- ✅ `logger()` для логирования отправок
- ✅ `chunk()` через `array_chunk()` для пакетной отправки

**Примеры:**

```php
use function Plugins\{validate_email, array_pluck, benchmark, logger};

$emails = array_pluck($subscribers, 'email');
$validEmails = array_filter($emails, 'Plugins\validate_email');

$result = benchmark(function() use ($validEmails) {
    return sendMailing($validEmails);
});

logger("Sent {$result['result']} emails in {$result['time']}s", 'info', 'mailing.log');
```

---

### 7. **gallery** - Галерея

**Что улучшить:**

- ✅ `formatBytes()` для отображения размера файлов
- ✅ `image_tag()` для генерации тегов изображений
- ✅ `paginate()` для постраничной навигации галереи
- ✅ `slug()` для создания URL галерей
- ✅ `truncate_html()` для описаний изображений

**Примеры:**

```php
use function Plugins\{formatBytes, image_tag, paginate, slug};

foreach ($images as &$img) {
    $img['size_formatted'] = formatBytes($img['filesize']);
    $img['html'] = image_tag($img['url'], $img['title'], ['class' => 'gallery-img']);
    $img['slug'] = slug($img['title']);
}

$pagination = paginate($currentPage, $totalPages, ['gallery' => $galleryId]);
```

---

### 8. **comments** - Комментарии

**Что улучшить:**

- ✅ `sanitize()` для очистки текста комментариев
- ✅ `validate_email()` для проверки email комментатора
- ✅ `csrf_field()` для защиты формы
- ✅ `is_post()` для проверки отправки
- ✅ `get_ip()` для сохранения IP
- ✅ `time_ago()` для отображения времени
- ✅ `is_ajax()` для AJAX комментариев

---

### 9. **auth_social** - Социальная авторизация

**Что улучшить:**

- ✅ `validate_email()` для проверки email из соцсетей
- ✅ `encrypt()` / `decrypt()` для хранения токенов
- ✅ `random_string()` для генерации state токенов
- ✅ `session()` для хранения данных авторизации
- ✅ `json_decode_safe()` для парсинга ответов API

---

### 10. **webpush** - Web Push уведомления

**Что улучшить:**

- ✅ `validate_url()` для проверки endpoint
- ✅ `is_mobile()` для определения устройства
- ✅ `json_validate()` для проверки payload
- ✅ `encrypt()` для шифрования данных
- ✅ `logger()` для логирования отправок

---

## 🔧 Средний приоритет

### 11. **archive** - Архив новостей

- ✅ `paginate()` для навигации по архиву
- ✅ `format_date()` для форматирования дат
- ✅ `cache_get/put()` для кэширования архива

### 12. **calendar** - Календарь

- ✅ `format_date()` для форматирования
- ✅ `cache_get/put()` для кэширования событий
- ✅ `array_pluck()` для извлечения дат

### 13. **faq** - FAQ

- ✅ `paginate()` для навигации
- ✅ `slug()` для URL вопросов
- ✅ `truncate_html()` для превью ответов
- ✅ `cache_get/put()` для кэширования

### 14. **guestbook** - Гостевая книга

- ✅ `sanitize()` для очистки сообщений
- ✅ `validate_email()` для проверки email
- ✅ `csrf_field()` для защиты
- ✅ `get_ip()` для IP
- ✅ `time_ago()` для времени

### 15. **sitemap** - Карта сайта

- ✅ `format_date()` для lastmod
- ✅ `cache_get/put()` для кэширования
- ✅ `array_pluck()` для извлечения URL

### 16. **rss_export** - RSS экспорт

- ✅ `format_date()` для pubDate
- ✅ `cache_get/put()` для кэширования фида
- ✅ `excerpt()` для описаний

### 17. **tags** - Теги

- ✅ `slug()` для URL тегов
- ✅ `array_pluck()` для извлечения тегов
- ✅ `paginate()` для навигации по тегам

### 18. **voting** - Опросы

- ✅ `is_ajax()` для голосования
- ✅ `get_ip()` для учета IP
- ✅ `percentage()` для результатов
- ✅ `cache_forget()` для сброса кэша после голосования

### 19. **pm** - Личные сообщения

- ✅ `sanitize()` для очистки сообщений
- ✅ `time_ago()` для времени
- ✅ `paginate()` для навигации по сообщениям
- ✅ `excerpt()` для превью

### 20. **search** (если есть плагин)

- ✅ `sanitize()` для очистки запросов
- ✅ `excerpt()` для результатов поиска
- ✅ `paginate()` для результатов
- ✅ `cache_get/put()` для кэширования популярных запросов

---

## 📊 Низкий приоритет (но можно улучшить)

### 21-30. Прочие плагины

- **autokeys** - `slug()`, `transliterate()`
- **booking** - `validate_email()`, `validate_phone()`, `format_date()`
- **complain** - `sanitize()`, `get_ip()`, `csrf_field()`
- **content_parser** - `str_between()`, `str_before()`, `str_after()`
- **holiday_decor** - `format_date()`, `cache_get/put()`
- **ipban** - `get_ip()`, `array_flatten()`
- **news_templates** - `slug()`, `excerpt()`
- **robots_editor** - `validate_url()`, `array_flatten()`
- **subscribe_comments** - `validate_email()`, `csrf_field()`
- **xfields** - `sanitize()`, `array_pluck()`

---

## 📝 Универсальные улучшения для всех плагинов

### Безопасность

```php
// Добавить во все формы
use function Plugins\{csrf_field, validate_csrf, sanitize};

// В форме
<?= csrf_field() ?>

// При обработке
if (!validate_csrf()) abort(403);
$data = sanitize($_POST);
```

### Кэширование

```php
// Заменить везде
use function Plugins\{cache_get, cache_put, cache_forget};

// Было:
cacheRetrieveFile($file, $expire, $plugin);
cacheStoreFile($file, $data, $plugin);

// Стало:
cache_get("plugin_{$key}");
cache_put("plugin_{$key}", $data, 30);
```

### Валидация

```php
// Добавить проверки
use function Plugins\{validate_email, validate_url, validate_phone};

if (!validate_email($email)) {
    $errors[] = 'Invalid email';
}
```

### Логирование

```php
// Добавить логирование важных событий
use function Plugins\logger;

logger("User action: {$action}", 'info', 'plugin.log');
logger("Error: {$error}", 'error', 'plugin.log');
```

---

## 🎯 План модернизации

### Этап 1: Критичные плагины (1-5)

Модернизировать плагины с формами и пользовательским вводом для повышения безопасности.

### Этап 2: Популярные плагины (6-10)

Улучшить производительность через кэширование и оптимизацию.

### Этап 3: Остальные плагины (11-30)

Постепенная модернизация для единообразия кода.

---

## 💡 Преимущества модернизации

1. **Безопасность** - CSRF защита, валидация, санитизация
2. **Производительность** - эффективное кэширование
3. **Читаемость** - единообразный код
4. **Отладка** - централизованное логирование
5. **Поддержка** - меньше дублирования кода
6. **Расширяемость** - легче добавлять новые функции

---

**Всего плагинов для улучшения: 30+**
**Потенциальная экономия кода: 40-60%**
**Улучшение безопасности: значительное**
